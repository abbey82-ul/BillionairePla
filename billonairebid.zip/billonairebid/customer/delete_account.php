<center><!-- center Begin -->
    
    <h1> Do You Realy Want To Delete Your Bid Account ? </h1>
    
    <form action="" method="post"><!-- form Begin -->
        
       <input type="submit" name="Yes" value="Yes, I Want To Delete" class="btn btn-danger"> 
        
       <input type="submit" name="No" value="No, I Dont Want To Delete" class="btn btn-primary"> 
        
    </form><!-- form Finish -->
    
</center><!-- center Finish -->


<?php 

$c_email = $_SESSION['bider_email'];

if(isset($_POST['Yes'])){
    
    $delete_bider = "delete from biders where bider_email='$bid_email'";
    
    $run_delete_bider = mysqli_query($con,$delete_bider);
    
    if($run_delete_bider){
        
        session_destroy();
        
        echo "<script>alert('Successfully delete your bid account, feel sorry about this. Good Bye')</script>";
        
        echo "<script>window.open('../index.php','_self')</script>";
        
    }
    
}

if(isset($_POST['No'])){
    
    echo "<script>window.open('my_account.php?my_orders','_self')</script>";
    
}

?>