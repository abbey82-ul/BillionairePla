<center><!--  center Begin  -->
    
    <h1> Pay Offline Using Biding Method </h1>
    
    <p class="text-muted">
        
        If you have any questions, feel free to <a href="../contact.php">Contact Us</a>. Our Bid Customer Service work <strong>24/7</strong>
        
    </p>
    
</center><!--  center Finish  -->


<hr>


<div class="table-responsive"><!--  table-responsive Begin  -->
    
    <table class="table table-bordered table-hover table-striped"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
            <tr><!--  tr Begin  -->
            
                <th> Bank Account Details: </th>
                <th> Easy Bid Pay, Bank of Ireland Details: </th>
                <th> Western Union Money Transfer Details: </th>

            </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
           
           <td> Bank Name: Bank of Ireland | Account No: 190-00-99 | Branch Name: Limerick | Branch Code: 1233 </td>
           <td> AIB #980-231-907 | Mobile No: 190-00-99  | Name: Emma </td>
           <td> Real Name: Mr Emma| Mobile No: 190-00-99  Country: Ireland | Name: Emma | AIB #190-00-99  </td>
            
        </tbody><!--  tbody Finish  -->
        
    </table><!--  table table-bordered table-hover Finish  -->
    
</div><!--  table-responsive Finish  -->